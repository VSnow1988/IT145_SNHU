//Vincent Snow
import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
	// Instance variables 
	private static Scanner scnr = new Scanner(System.in);
	private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();
    
    //Main method runs the menu loop and directs behavior
    public static void main(String[] args) {
    	String menuChoice = "";
        initializeDogList();
        initializeMonkeyList();

        //Menu loop, presents numbered choices and displays message if invalid selection is made.         
        while (menuChoice != "q") {
        	displayMenu();
        	menuChoice = scnr.next();
        	scnr.nextLine();
	        switch (menuChoice) {
		        case "1": intakeNewDog(scnr);
		        		break;
		        case "2": intakeNewMonkey(scnr);
		        		break;
		        case "3": reserveAnimal(scnr);
		        		break;
		        case "4": printAnimals("dog");
		        		break;
		        case "5": printAnimals("monkey");
		        		break;
		        case "6": printAnimals("available");
		        		break;
		        case "q": System.exit(0);
		        		break;
		        default: System.out.println("Invalid input.");
		        		
        	}
        }
    }

    // This method prints the menu options.
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // Adds dogs to a list for testing.
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", true, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", false, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }


    // Adds monkeys to a list for testing.
    public static void initializeMonkeyList() {
    	Monkey monkey1 = new Monkey("Pete", "Macaque", "male", "22", "80kg", "9m", "3m", "3m", "01-01-2021", "Venezuela", "Phase I", true, "Russia");
    	Monkey monkey2 = new Monkey("Sven", "Capuchin", "male", "13", "5kg", "3m", "20m", "20m", "03-30-2013", "Maldives", "intake", false, "Maldives");
    	Monkey monkey3 = new Monkey("Pudding", "Guenon", "female", "300", "5000kg", "50m", "15m", "15m", "02-12-2019", "Iceland", "in service", false, "Mexico");
    	
    	monkeyList.add(monkey1);
    	monkeyList.add(monkey2);
    	monkeyList.add(monkey3);
    }


    // Dog intake method, validates input and adds new dog based on user input.
    public static void intakeNewDog(Scanner scanner) {
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        for(Dog dog: dogList) {
            if(dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");
                return; //returns to menu
            }
        }
        System.out.println("What is the dog's breed? ");
        String breed = scanner.nextLine();
        System.out.println("What is the dog's gender? ");
        String gender = scanner.nextLine();
        System.out.println("What is the dog's age? ");
        String age = scanner.nextLine();
        System.out.println("What is the dog's weight? ");
        String weight = scanner.nextLine();
        System.out.println("When was the dog acquired? ");
        String acquisitionDate = scanner.nextLine();
        System.out.println("Where was the dog acquired? ");
        String acquisitionCountry = scanner.nextLine();
        System.out.println("What is the dog's training status? ");
        String trainingStatus = scanner.nextLine();
        System.out.println("What is the dog's area of service? ");
        String inServiceCountry = scanner.nextLine();
        //Loop and verification for whether dog is reserved
        String inputAnswer = "";
        Boolean reserved = null;
        while (inputAnswer == ""){
            System.out.println("Is the dog reserved? [y] or [n]");
            inputAnswer = scanner.next();
            scanner.nextLine();
            switch (inputAnswer) {
            	case "y": reserved = true;
            			break;
            	case "n": reserved = false;
            			break;
            	default:
            		inputAnswer = "";
            		System.out.println("Invalid input.");
            }
        }
        
        //Add the dog to the list
        Dog newDog = new Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry);
        dogList.add(newDog);
        System.out.print(name);
        System.out.println(" was added to the Dog registry.");
    }


    //Monkey intake method, validates the input and creates a new monkey entry based on user input.
    public static void intakeNewMonkey(Scanner scanner) {
        System.out.println("What is the monkey's name?");
        String name = scanner.nextLine();
        for (Monkey monkey: monkeyList) {
        	if(monkey.getName().equalsIgnoreCase(name) ) {
        		System.out.println("\n\nThis monkey is already in our system\n\n");
                return; //returns to menu
        	}
        }
        //Loop and verification for choosing from the valid monkey breeds
        System.out.println("What is the monkey's species?");
        System.out.println("Enter a letter: [1]Capuchin [2]Guenon [3]Macaque [4]Marmoset [5]Squirrel monkey [6]Tamarin");
        String species = "";
        String speciesSelection = scanner.next();
        scanner.nextLine();
        while (speciesSelection == "") {
            switch (speciesSelection) {
	        	case "1": species = "Capuchin";
	        			break;
	        	case "2": species = "Guenon";
	        			break;
	        	case "3": species = "Macaque";
	        			break;
	        	case "4": species = "Marmoset";
	        			break;
	        	case "5": species = "Squirrel Monkey";
	        			break;
	        	case "6": species = "Tamarin";
	        			break;
	        	default:
	        			speciesSelection = "";
	        			System.out.print("Please enter a valid input or q to go to the main menu.");
            }
        }
        System.out.println("How old is the monkey?");
        String age = scanner.nextLine();
        System.out.println("What is the monkey's gender?");
        String gender = scanner.nextLine();
        System.out.println("What is the monkey's weight?");
        String weight = scanner.nextLine();
        System.out.println("What is the monkey's height?");
        String height = scanner.nextLine();
        System.out.println("What is the monkey's tail length?");
        String tailLength = scanner.nextLine();
        System.out.println("What is the monkey's body length?");
        String bodyLength = scanner.nextLine();
        System.out.println("What date was the monkey aqcuired?");
        String acquisitionDate = scanner.nextLine();
        System.out.println("What country was the monkey aqcuired in?");
        String acquisitionCountry = scanner.nextLine();
        System.out.println("What is the monkey's current training status?");
        String trainingStatus = scanner.nextLine();
        System.out.println("What is the monkey's service country?");
        String inServiceCountry = scanner.nextLine();
        //Loop and verification for setting reservation status
        String inputAnswer = "";
        Boolean reserved = null;
        while (inputAnswer == ""){
            System.out.println("Is the monkey reserved? [y] or [n]");
            inputAnswer = scanner.next();
            scanner.nextLine();
            switch (inputAnswer) {
            	case "y": reserved = true;
            			break;
            	case "n": reserved = false;
            			break;
            	default:
            		inputAnswer = "";
            		System.out.println("Invalid input.");
            }
        }
        
        //Add the monkey to the list
        Monkey newMonkey = new Monkey(name, species, gender, age, weight, tailLength, height, bodyLength, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry);
        monkeyList.add(newMonkey);
        System.out.print(name);
        System.out.println(" was added to the Monkey registry.");
    }

       
    //Method to reserve an animal
    public static void reserveAnimal(Scanner scanner) {
    	System.out.println("What country is the animal's service requested in?");
        String inServiceCountry = scanner.nextLine();
        int inputChoice = 0;
        while (inputChoice == 0){
            System.out.println("What type of animal would you like to reserve? [1] Dog [2] Monkey");
            inputChoice = scanner.nextInt();
            scanner.nextLine();
            switch (inputChoice) {
            	case 1:	//Present dogs available one by one and ask to reserve. Display error if user says 'no' on last available dog
            			for (Dog dog : dogList) {
            				if (dog.getInServiceLocation().equals(inServiceCountry) && dog.getReserved() == false) {
            					System.out.print("Would you like to reserve ");
            					System.out.print(dog.getName());
            					System.out.print(", a ");
            					System.out.print(dog.getAge());
            					System.out.print(" year old ");
            					System.out.print(dog.getBreed());
            					System.out.println("? (y/n)");
            					
            					String inputAnswer = "";
                				while (inputAnswer =="") {
                					inputAnswer = scanner.next();
                					scanner.nextLine();
                					switch (inputAnswer) {
                	            	case "y": dog.setReserved(true);
                	            			System.out.println(dog.getName() + " has been reserved.");
                	            			return; // Go to main menu
                	            	case "n": 
                	            			break;
                	            	default:
                	            		inputAnswer = "";
                	            		System.out.println("Invalid input.");
                					}              				
                				}                    			
            				}
            			}
            			System.out.println("No more dogs are available in this location.");
            			break;
            			
            	case 2: //Iterate through available monkeys and ask to reserve. Display error when the end is reached if user selects 'no'
            		for (Monkey monkey : monkeyList) {
        				if (monkey.getInServiceLocation().equals(inServiceCountry) && monkey.getReserved() == false) {
        					System.out.print("Would you like to reserve ");
        					System.out.print(monkey.getName());
        					System.out.print(", a ");
        					System.out.print(monkey.getAge());
        					System.out.print(" year old ");
        					System.out.print(monkey.getSpecies());
        					System.out.println("? (y/n)");
        					
        					String inputAnswer = "";
            				while (inputAnswer =="") {
            					inputAnswer = scanner.next();
            					scanner.nextLine();
            					switch (inputAnswer) {
            	            	case "y": monkey.setReserved(true);
            	            			System.out.println(monkey.getName() + " has been reserved.");
            	            			return; // Go to main menu
            	            	case "n": 
            	            			break;
            	            	default:
            	            		inputAnswer = "";
            	            		System.out.println("Invalid input.");
            					}              				
            				}                				
        				}
        			}
            		System.out.println("No more monkeys are available in this location.");
        			break;
        			
               	default:
               		inputChoice = 0;
            		System.out.println("Invalid input.");
            }
          }          
        }
        
    //Print a list of all animals of specified type, or all available animals (in service and not reserved).
    public static void printAnimals(String listType) {        	
    	if (listType.equals("dog")) {
    		System.out.println("List of all dogs:");
    		for (Dog dog: dogList) {
    			System.out.print(dog.getName() + ": " + dog.getTrainingStatus() + ". Acquired in " + dog.getAcquisitionLocation() + ". ");
    			if (dog.getReserved() == true) {
    				System.out.println("(RESERVED)");
    			}
    			else {
    				System.out.println("(AVAILABLE)");
    			}
    		}
    	}
    	else if (listType.equals("monkey")) {
    		System.out.println("List of all monkeys:");
    		for (Monkey monkey: monkeyList) {
    			System.out.print(monkey.getName() + ": " + monkey.getTrainingStatus() + ". Acquired in " + monkey.getAcquisitionLocation() + ". ");
    			if (monkey.getReserved() == true) {
    				System.out.println("(RESERVED)");
    			}
    			else {
    				System.out.println("(AVAILABLE)");
    			}
    		}
    	}
    	else if (listType.equals("available")) {
    		ArrayList<RescueAnimal> animalsList = new ArrayList<RescueAnimal>();
    		animalsList.addAll(monkeyList);
    		animalsList.addAll(dogList);
    		System.out.println("List of available animals:");
    		for (RescueAnimal animal: animalsList) {
    			if (animal.getReserved() == false && animal.getTrainingStatus().equals("in service")) {
    				System.out.println(animal.getName() + ": " + animal.getAnimalType() + ". "+ animal.getTrainingStatus() + ". Acquired in " + animal.getAcquisitionLocation() + ". ");
    			}
    		}
    		
    	}
    }
}

