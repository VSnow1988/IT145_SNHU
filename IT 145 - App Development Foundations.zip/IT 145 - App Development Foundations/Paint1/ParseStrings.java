import java.util.Scanner;
import java.util.InputMismatchException;

public class ParseStrings {
   public static void main(String[] args) throws InputMismatchException {
      Scanner scnr = new Scanner(System.in);
      Boolean comma = false;
      String word1 = "";
      String word2 = "";
      String userInput = "";
      
      //Code to run until user inputs 'q'
      while(userInput != "q"){
         comma = false;   
         //Keep prompting for input and throw an error if there is no string in the comma
         while(comma == false){
            try {
               System.out.println("Enter input string: ");
               userInput = scnr.nextLine();
               if (userInput.equals("q")) {
            	   System.exit(0);
               }
               else if (userInput.contains(",")){
                     comma = true;
                  }
               
               if (comma == false){ 
                  throw new InputMismatchException("Error: No comma in string");
               }
            }
            catch(Exception fail){
               System.out.println(fail.getMessage());
            }
         }
        
         //Clip out whitespace and separate the String into two words, then print.
         String[] userWords = userInput.split(",");
         word1 = userWords[0].replaceAll("\\s", "");
         word2 = userWords[1].replaceAll("\\s", "");
         
         System.out.print("First word: ");
         System.out.println(word1);
         System.out.print("Second word: ");
         System.out.println(word2);
         System.out.println();
         System.out.println();
      }
   scnr.close();
   }
}
