//Vincent Snow IT145
import java.util.InputMismatchException;
import java.util.Scanner;

public class Paint1 {
	private static Scanner scnr = new Scanner(System.in);
	
    public static void main(String[] args) {
        
        double wallHeight = 0.0;
        double wallWidth = 0.0;
        double wallArea = 0.0;
        double gallonsPaintNeeded = 0.0;
        
        final double squareFeetPerGallons = 350.0;
        
        // Implement a do-while loop to ensure input is valid
        // Prompt user to input wall's height
        while (wallHeight == 0.0) {
        	try {
        		System.out.println("Enter wall height (feet): ");
        		wallHeight = scnr.nextDouble();
        		
	        
	        	if (wallHeight == 0.0) {
	        		throw new InputMismatchException("Wall height is invalid.");
	        	}
	        }
	        catch (Exception fail) {
	        	System.out.println(fail.getMessage());
	        	System.out.println("Please enter a decimal value or an integer above zero.");
	        	scnr.nextLine();
	        }
        }

        // Implement a do-while loop to ensure input is valid
        // Prompt user to input wall's width
        
        while (wallWidth == 0.0) {
        	try {
        		System.out.println("Enter wall width (feet): ");
        		wallWidth = scnr.nextDouble();
        		        		
        		if (wallWidth == 0.0) {
        			throw new InputMismatchException("Wall width is invalid.");
        		}
        	}
        		catch (Exception fail) {
    	        	System.out.println(fail.getMessage());
    	        	System.out.println("Please enter a decimal value or an integer above zero.");
    	        	scnr.nextLine();
    	        }
        }
        

        // Calculate and output wall area
        wallArea = wallHeight * wallWidth;
        System.out.println("Wall area: " + wallArea + " square feet");

        // Calculate and output the amount of paint (in gallons) needed to paint the wall
        gallonsPaintNeeded = wallArea/squareFeetPerGallons;
        System.out.println("Paint needed: " + gallonsPaintNeeded + " gallons");

        scnr.close();
    }
}
