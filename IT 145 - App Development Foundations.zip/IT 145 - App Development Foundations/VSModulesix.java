import java.util.Scanner;

public class ParseStrings {
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      Boolean comma = false;
      String word1 = "";
      String word2 = "";
      String userInput = "";
      
      while(userInput != "q"){
         System.out.println("Enter input string: ");
         userInput = scnr.nextLine();
         
         //Prompt input and continue to if a comma does not exist in the String
         while(comma == false){
            for (int i = 0; i < userInput.length(); i++){
                  if (userInput.charAt(i) == ','){
                  comma = true;
               }
            }
            if (comma == false){
               System.out.println("Error: No comma in string");
               return;
            }
         }
         
         //Clip out whitespace and separate the String into two words, then print.
         String[] userWords = userInput.split(",");
         word1 = userWords[0].replaceAll("\\s", "");
         word2 = userWords[1].replaceAll("\\s", "");
         
         System.out.print("First word: ");
         System.out.println(word1);
         System.out.print("Second word: ");
         System.out.println(word2);
      }
   }
}