// Vincent Snow IT145-X2999

public class Cat extends Pet {
	
	private int catSpaceNumber;
	
	//Default constructor method
	public Cat() {
		catSpaceNumber = 0;
	}
	
	//Overloaded constructor method
	public Cat(int catSpaceNumber) {
		this.catSpaceNumber = catSpaceNumber;
	}
	
	//Methods to set and get the cat's space number
	public int getCatSpaceNumber() {
		return this.catSpaceNumber;
	}
	public static void setCatSpaceNumber(int catSpaceNumber) {
		this.catSpaceNumber = catSpaceNumber;
	}
	
}
