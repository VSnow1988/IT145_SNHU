// Vincent Snow IT145 Project 1
public class Pet {
	private String petType;
	private String petName;
	private int petAge;
	private int dogSpaces;
	private int catSpaces;
	private int daysStay;
	private int amountDue;
	
	//Default Constructor
	public Pet() {
		petType = "";
		petName = "";
		petAge = 0;
		dogSpaces = 30;
		catSpaces = 12;
		amountDue = 0;
		daysStay = 0;
	}
	
	//Methods to retrieve and Update pet type
	public static String getPetType() {
		return this.petType;
	}
	public static void setPetType(String petType) {
		this.petType = petType;
	}
	
	//Methods to retrieve and update pet name
	public static String getPetName() {
		return this.petName;
	}
	
	public static void setPetName(String petName) {
		this.petName = petName;
	}
	
	//Methods to retrieve and update pet age
	public static int getPetAge() {
		return this.petAge;
	}
	
	public static void setPetAge(String petAge) {
		this.petAge = petAge;
	}
	//Methods to retrieve and update pet spaces
	public static int getDogSpaces() {
		return Pet.dogSpaces;
	}
	
	public static void setDogSpaces(int dogSpaces) {
		Pet.dogSpaces = dogSpaces;
	}
	
	public static int getCatSpaces() {
		return Pet.catSpaces;
	}
	
	public static void setCatSpaces(int catSpaces) {
		Pet.catSpaces = catSpaces;
	}
	
	//Methods to check and update days of stay
	public static int getDaysStay() {
		return this.daysStay;
	}
	
	public static void setDaysStay(int daysStay) {
		this.daysStay = daysStay;
	}
	
	//Methods for amount due
	public static double getamountDue() {
		return (this.amountDue * 0.01);
	}
	
	public static void setAmountDue(int amountDue) {
		this.amountDue = amountDue;
	}
}
